CKEDITOR.plugins.setLang("pbckcode","en",
{
	title: 'Add code',
});